/* (v4.97) While any window, dialog or sheet is open, the page behind it can't be scrolled, dragged or touched.
   Inside the window, touch still works; only parts that can really scroll (a long list) move. */
(function () {
  'use strict';
  const SEL = '.overlay:not([hidden]), .qd-ov:not([hidden]), .bk-ov, .dp-ov:not([hidden]), .ld-ov:not([hidden]), .rm-ov, .sv-ov, ' +
    '.tp-overlay:not([hidden]), .ty-ov:not([hidden]), .ty-overlay:not([hidden]), .csh-ov, .sw-tip, #savedBox:not([hidden]), ' +
    '.job-sheet:not([hidden]), .pb-overlay, .pm-overlay, #topMenuBox:not([hidden]), .ac-ov, .ac-anim';
  const shown = el => { if (!el.getClientRects().length) return false; const c = getComputedStyle(el); return c.visibility !== 'hidden' && c.display !== 'none' && +c.opacity > 0.05; };
  const openOnes = () => [...document.querySelectorAll(SEL)].filter(shown);
  let locked = false;
  function sync() {
    const on = openOnes().length > 0;
    if (on === locked) return;
    locked = on;
    document.documentElement.classList.toggle('modal-lock', on);
  }
  new MutationObserver(() => requestAnimationFrame(sync)).observe(document.documentElement, { subtree: true, childList: true, attributes: true, attributeFilter: ['hidden', 'class', 'style'] });
  // can this element (or a parent inside the window) scroll in the direction of the finger?
  const scrollsInside = (t, win, dy, dx) => {
    for (let el = t; el && el !== win.parentElement; el = el.parentElement) {
      if (!(el instanceof Element)) break;
      const c = getComputedStyle(el);
      const y = /(auto|scroll)/.test(c.overflowY) && el.scrollHeight > el.clientHeight + 1;
      const x = /(auto|scroll)/.test(c.overflowX) && el.scrollWidth > el.clientWidth + 1;
      if (y && Math.abs(dy) >= Math.abs(dx)) { if ((dy > 0 && el.scrollTop > 0) || (dy < 0 && el.scrollTop + el.clientHeight < el.scrollHeight - 1)) return true; }
      if (x && Math.abs(dx) > Math.abs(dy)) return true;
      if (el.classList && (el.classList.contains('dp-wheel') || el.classList.contains('cc') || el.matches('input[type=range]'))) return true;   // wheels, colour rows, sliders handle their own drag
      if (el === win) break;
    }
    return false;
  };
  let sx = 0, sy = 0;
  document.addEventListener('touchstart', e => { const t = e.touches[0]; sx = t.clientX; sy = t.clientY; }, { capture: true, passive: true });
  document.addEventListener('touchmove', e => {
    if (!locked) return;
    const t = e.touches[0], dy = t.clientY - sy, dx = t.clientX - sx;
    const win = openOnes().find(w => w.contains(e.target));
    if (!win || !scrollsInside(e.target, win, dy, dx)) { if (e.cancelable) e.preventDefault(); }
  }, { capture: true, passive: false });
  document.addEventListener('wheel', e => {
    if (!locked) return;
    const win = openOnes().find(w => w.contains(e.target));
    if (!win || !scrollsInside(e.target, win, -e.deltaY, -e.deltaX)) e.preventDefault();
  }, { capture: true, passive: false });
  window.RichModalLock = { sync };
})();
