package com.richcvmaker.app;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import com.google.firebase.messaging.FirebaseMessaging;

/** (v4.99) Push notifications (Firebase Cloud Messaging).
 *  Every phone joins the topic "all" and one topic for its app language ("lang_en", "lang_ar" ...),
 *  so a message can be sent to everyone, or to one language, from the Firebase console. */
final class Notify {
    static final String CHANNEL = "news";
    static final int PERMISSION_REQUEST = 7301;
    private static final String PREFS = "rich_notify";

    private Notify() { }

    /** The "Updates and tips" category the user sees in Android settings, and the "all" topic. */
    static void setup(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                NotificationManager nm = c.getSystemService(NotificationManager.class);
                if (nm != null && nm.getNotificationChannel(CHANNEL) == null) {
                    NotificationChannel ch = new NotificationChannel(CHANNEL, "Updates and tips", NotificationManager.IMPORTANCE_DEFAULT);
                    ch.setDescription("New templates, tips and news from Rich CV Maker");
                    nm.createNotificationChannel(ch);
                }
            } catch (Exception ignored) { }
        }
        try { FirebaseMessaging.getInstance().subscribeToTopic("all"); } catch (Throwable ignored) { }   // no Firebase file: nothing to do
    }

    /** Moves the phone to the topic of the app language (leaving the old one). */
    static void setLanguage(Context c, String lang) {
        if (lang == null) return;
        String code = lang.toLowerCase().replaceAll("[^a-z]", "");
        if (code.isEmpty() || code.length() > 5) return;
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String old = p.getString("lang", "");
        if (code.equals(old)) return;
        try {
            FirebaseMessaging fm = FirebaseMessaging.getInstance();
            if (!old.isEmpty()) fm.unsubscribeFromTopic("lang_" + old);
            fm.subscribeToTopic("lang_" + code);
            p.edit().putString("lang", code).apply();
        } catch (Throwable ignored) { }
    }

    /** "yes", "no", or "ask" (Android 13+ and the user has not answered yet). */
    static String state(Activity a) {
        boolean on;
        if (Build.VERSION.SDK_INT >= 33) on = a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        else on = androidx.core.app.NotificationManagerCompat.from(a).areNotificationsEnabled();
        if (on) return "yes";
        if (Build.VERSION.SDK_INT >= 33 && !a.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("asked", false)) return "ask";
        return "no";
    }

    /** Android's own "Allow notifications?" (Android 13+). Older phones: notifications are on already. */
    static void ask(Activity a) {
        if (Build.VERSION.SDK_INT < 33) return;
        a.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("asked", true).apply();
        a.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, PERMISSION_REQUEST);
    }

    /** Android's notification page for this app (to switch them on after "Don't allow"). */
    static void openSettings(Activity a) {
        try {
            Intent it;
            if (Build.VERSION.SDK_INT >= 26) it = new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, a.getPackageName());
            else it = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(android.net.Uri.parse("package:" + a.getPackageName()));
            a.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) { }
    }

    /** Which page a tapped notification asks to open (data key "open"): tools, templates, cvs, downloads, premium, new. */
    static String openFrom(Intent it) {
        if (it == null) return null;
        String v = it.getStringExtra("open");
        if (v == null) return null;
        v = v.toLowerCase().replaceAll("[^a-z]", "");
        return v.isEmpty() ? null : v;
    }
}
