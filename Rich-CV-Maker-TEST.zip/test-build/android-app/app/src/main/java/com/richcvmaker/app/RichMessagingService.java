package com.richcvmaker.app;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

/** (v4.99) Receives Firebase notifications. When the app is closed or in the background Android shows them by itself;
 *  this class shows them while the app is open, and opens the page named in the data key "open" when tapped. */
public class RichMessagingService extends FirebaseMessagingService {

    @Override
    public void onMessageReceived(@NonNull RemoteMessage msg) {
        Map<String, String> data = msg.getData();
        String title = null, body = null;
        if (msg.getNotification() != null) { title = msg.getNotification().getTitle(); body = msg.getNotification().getBody(); }
        if (title == null) title = data.get("title");
        if (body == null) body = data.get("body");
        if (title == null && body == null) return;

        Notify.setup(this);
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        String page = data.get("open");
        if (page != null) open.putExtra("open", page);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent pi = PendingIntent.getActivity(this, (int) (System.currentTimeMillis() & 0xfffffff), open, flags);

        NotificationCompat.Builder b = new NotificationCompat.Builder(this, Notify.CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_notify)
                .setColor(0xFF1A5FE8)
                .setContentTitle(title != null ? title : getString(R.string.app_name))
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        try { NotificationManagerCompat.from(this).notify((int) (System.currentTimeMillis() & 0xfffffff), b.build()); }
        catch (SecurityException ignored) { }   // the user did not allow notifications
    }

    @Override
    public void onNewToken(@NonNull String token) {
        // Topics are used (all, lang_xx), so the token does not need to be sent anywhere.
    }
}
